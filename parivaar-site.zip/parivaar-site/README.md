# Parivaar AI website – setup guide

This folder is a complete website. Customers choose a plan, pay with Google Pay,
PhonePe, Paytm or any UPI app, and **their login code appears on screen as soon as
Razorpay confirms the payment**. The server also enforces the device limit
across every phone, and you get an admin page to see payments and codes.

```
parivaar-site/
├── server.js          ← the server (payments, codes, logins, admin)
├── plans.js           ← EDIT prices, devices, days, trial length here
├── db.js              ← database (a single file: data/parivaar.db)
├── .env.example       ← settings template → copy to .env
├── public/            ← the website pages
│   ├── index.html     ← main site + app
│   ├── terms.html, privacy.html, refunds.html, contact.html  ← EDIT the [yellow] parts
└── admin/admin.html   ← your admin page (opens at /admin)
```

---

## How a payment works

1. The customer picks a plan and enters their name and mobile number.
2. The Razorpay payment window opens with UPI first. They choose GPay, PhonePe,
   Paytm etc. on a phone, or scan a QR on a computer.
3. Razorpay tells the server the payment succeeded. The server **checks the payment
   signature and asks Razorpay directly that the full amount was received**. Only
   then does it create the login code.
4. The code appears on screen with *Copy*, *Share on WhatsApp* and
   *Start using it on this device*.
5. If they close the page too early, the code still appears the next time they open the site.
   They can also use **Find my code** with their mobile number and payment ID.
   The Razorpay webhook also records the payment on its own.

Money goes to your Razorpay account, and Razorpay sends it to your bank account
(usually within 2 working days). Razorpay charges a small fee per payment. Check
their current pricing.

---

## Step 1 – Create a Razorpay account

1. Sign up at **razorpay.com**. Individuals and unregistered businesses can usually
   sign up with a PAN card and a bank account. Check Razorpay's current requirements.
2. You can use **Test mode** straight away. Go to **Account & Settings → API Keys →
   Generate Test Key**. Copy the **Key ID** (`rzp_test_…`) and **Key Secret**.
3. Live payments are switched on after Razorpay checks your documents and your
   website (Step 5).

## Step 2 – Put the website online

The site needs a host that runs **Node.js** and keeps one file saved (the database).
Here is one simple way using **Render** (render.com). Any Node.js host or small
VPS works too.

1. Make a free **GitHub** account. Create a **private** repository and drag the
   *contents* of this folder into it (*Add file → Upload files*). **Never upload a `.env` file.**
2. On **Render**, choose *New → Web Service* and connect the repository.
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: choose a paid one (for example *Starter*). Free instances go to sleep and
     **don't keep the database**, so customers' codes would be lost.
3. Under **Disks**, add a disk: mount path `/var/data`, size 1 GB.
4. Under **Environment**, add these settings:

| Name | Value |
|---|---|
| `RAZORPAY_KEY_ID` | your `rzp_test_…` key ID |
| `RAZORPAY_KEY_SECRET` | your key secret |
| `RAZORPAY_WEBHOOK_SECRET` | any long random text you make up |
| `ADMIN_PASSWORD` | a strong password, at least 10 characters |
| `SUPPORT_PHONE` | `919980782985` |
| `DB_PATH` | `/var/data/parivaar.db` |

5. Deploy. Render gives you a web address like `https://parivaar.onrender.com`.
   You can connect your own domain later.

## Step 3 – Turn on the webhook (backup confirmation)

In Razorpay go to **Account & Settings → Webhooks → Add new webhook**:
- URL: `https://YOUR-WEBSITE/api/webhooks/razorpay`
- Secret: the same text you used for `RAZORPAY_WEBHOOK_SECRET`
- Events: tick **payment.captured** and **order.paid**

## Step 4 – Test it (no real money)

With test keys, open your site, choose a plan and pay:
- **UPI:** use the UPI ID `success@razorpay` to make a payment succeed, or
  `failure@razorpay` to see a failed payment.
- Check that the code appears, that you can log in, and that one more phone than the plan allows sees
  "Maximum devices have already been logged in".
- Open `https://YOUR-WEBSITE/admin`. The browser asks for a username (type anything) and
  your `ADMIN_PASSWORD`.

## Step 5 – Go live

1. Fill in every **[yellow]** part of `public/terms.html`, `privacy.html`, `refunds.html`
   and `contact.html`: your name, address, email and city. Razorpay checks these pages
   before approving your website. Read them and change anything that doesn't match how
   you run things (for example your refund rules). They are templates, not legal advice.
2. In Razorpay, finish KYC and add your website address.
3. When approved, generate **Live keys** and replace the two `RAZORPAY_…` settings with them
   (`rzp_live_…`). Add the webhook again in Live mode. Redeploy.

---

## Everyday use

- **Admin page** (`/admin`): see payments, search customers, and copy codes.
  - **Log out all devices**: frees every slot on a code, for example when a customer changed phones.
  - **+ Days**: adds free days to a plan.
  - **Cancel**: blocks a code.
  - **Give a code by hand**: for someone who paid you in cash.
- **Change prices or plans:** edit `plans.js`, upload it again, and Render redeploys.
- **Customers renewing:** they open *Renew / upgrade* under **Devices**, or type their
  old code under *Renewing? Keep your same code*. The family stays logged in and the days are added.
- **Back up** the database file (`/var/data/parivaar.db`) now and then. Render's disk
  page has snapshots.

## Run it on your own computer (optional)

```
npm install
cp .env.example .env     # then fill in .env
npm start                # open http://localhost:3000
```

## What the free trial does and doesn't do

The 7‑day trial is tracked in each browser, so someone could start a new trial by
clearing their browser data. Paid plans and device limits are fully checked by the
server and can't be bypassed that way.
