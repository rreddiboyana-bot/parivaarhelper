// SQLite database. The file lives in ./data/parivaar.db unless DB_PATH is set.
// Back up this file regularly – it holds every customer's subscription.
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const file = process.env.DB_PATH || path.join(__dirname, "data", "parivaar.db");
fs.mkdirSync(path.dirname(file), { recursive: true });

const db = new Database(file);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS subscriptions (
  id          INTEGER PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,
  plan_id     TEXT NOT NULL,
  max_devices INTEGER NOT NULL,
  name        TEXT,
  phone       TEXT,
  email       TEXT,
  source      TEXT NOT NULL,            -- 'razorpay' or 'manual'
  status      TEXT NOT NULL DEFAULT 'active',  -- 'active' or 'cancelled'
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id           TEXT PRIMARY KEY,         -- Razorpay order id
  plan_id      TEXT NOT NULL,
  amount       INTEGER NOT NULL,         -- in paise
  name         TEXT,
  phone        TEXT,
  email        TEXT,
  renew_sub_id INTEGER,
  status       TEXT NOT NULL,            -- 'created' or 'paid'
  payment_id   TEXT UNIQUE,
  sub_id       INTEGER,
  created_at   INTEGER NOT NULL,
  paid_at      INTEGER
);
CREATE TABLE IF NOT EXISTS devices (
  id         INTEGER PRIMARY KEY,
  sub_id     INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  device_id  TEXT NOT NULL,
  name       TEXT,
  token_hash TEXT,
  created_at INTEGER NOT NULL,
  last_seen  INTEGER,
  UNIQUE (sub_id, device_id)
);
CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(phone);
CREATE INDEX IF NOT EXISTS idx_devices_token ON devices(token_hash);
`);

module.exports = db;
