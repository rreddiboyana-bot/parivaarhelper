// ============================================================
//  Parivaar AI – website server
//  - Takes payments through Razorpay (UPI: GPay, PhonePe, Paytm…)
//  - Verifies every payment with Razorpay before giving a code
//  - Issues login codes and enforces the device limit per plan
//  - Owner admin page at /admin
//  Settings come from the .env file (see .env.example).
// ============================================================
require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const path = require("path");
const db = require("./db");
const { PLANS, TRIAL_DAYS } = require("./plans");

const PORT = process.env.PORT || 3000;
const KEY_ID = process.env.RAZORPAY_KEY_ID || "";
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "";
const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || "";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const RZP_BASE = process.env.RAZORPAY_API_BASE || "https://api.razorpay.com";
const BUSINESS = {
  name: process.env.BUSINESS_NAME || "Parivaar AI",
  supportPhone: process.env.SUPPORT_PHONE || "",
  supportEmail: process.env.SUPPORT_EMAIL || ""
};
const DAY = 864e5;

if (!KEY_ID || !KEY_SECRET) console.warn("⚠  RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET are not set – payments will not work.");
if (!WEBHOOK_SECRET) console.warn("⚠  RAZORPAY_WEBHOOK_SECRET is not set – the backup webhook is off.");
if (ADMIN_PASSWORD.length < 10) console.warn("⚠  ADMIN_PASSWORD must be at least 10 characters – the admin page is locked until you set one.");

const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.set("X-Content-Type-Options", "nosniff");
  res.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.set("X-Frame-Options", "SAMEORIGIN");
  next();
});

// ---------------- helpers ----------------
const planById = id => PLANS.find(p => p.id === id);
const publicPlan = p => ({ id: p.id, name: p.name, price: p.price, period: p.period, days: p.days, devices: p.devices, blurb: p.blurb, popular: !!p.popular });
const sha256 = s => crypto.createHash("sha256").update(s).digest("hex");
function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
function fail(res, status, error, extra) { return res.status(status).json({ error, ...extra }); }
const fmtDate = ms => new Date(ms).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Kolkata" });

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I to avoid confusion
function randomCode() {
  const bytes = crypto.randomBytes(8);
  let s = "";
  for (const b of bytes) s += CODE_CHARS[b % CODE_CHARS.length];
  return `PA-${s.slice(0, 4)}-${s.slice(4)}`;
}
function newUniqueCode() {
  for (;;) { const c = randomCode(); if (!db.prepare("SELECT 1 FROM subscriptions WHERE code=?").get(c)) return c; }
}
const normCode = c => String(c || "").toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/^PA(?=[A-Z0-9]{8}$)/, "").replace(/^(.{4})(.{4})$/, "PA-$1-$2");
const normPhone = p => String(p || "").replace(/\D/g, "").replace(/^(91|0)(?=\d{10}$)/, "");

// Simple in-memory rate limiter (per IP) to stop code guessing and spam.
function limiter(max, windowMs) {
  const hits = new Map();
  return (req, res, next) => {
    const now = Date.now(), key = req.ip;
    let h = hits.get(key);
    if (!h || now > h.reset) { h = { n: 0, reset: now + windowMs }; hits.set(key, h); }
    if (++h.n > max) return fail(res, 429, "Too many attempts. Please wait a few minutes and try again.");
    if (hits.size > 10000) for (const [k, v] of hits) if (now > v.reset) hits.delete(k);
    next();
  };
}

// Razorpay REST API
async function rzp(method, pathname, body) {
  if (!KEY_ID || !KEY_SECRET) { const e = new Error("Payments are not set up yet. Please contact us."); e.status = 503; e.expose = true; throw e; }
  const r = await fetch(RZP_BASE + pathname, {
    method,
    headers: { Authorization: "Basic " + Buffer.from(`${KEY_ID}:${KEY_SECRET}`).toString("base64"), "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    console.error("Razorpay error", r.status, pathname, j && j.error);
    const e = new Error("The payment service is not responding. Please try again."); e.status = 502; e.expose = true; throw e;
  }
  return j;
}

function subInfo(sub, opts = {}) {
  const plan = planById(sub.plan_id) || { name: sub.plan_id };
  const used = db.prepare("SELECT COUNT(*) n FROM devices WHERE sub_id=?").get(sub.id).n;
  return {
    code: sub.code, plan: plan.name, planId: sub.plan_id, maxDevices: sub.max_devices, devicesUsed: used,
    expiresAt: sub.expires_at, expiresOn: fmtDate(sub.expires_at), name: sub.name, ...opts
  };
}

// Give the customer their code once a payment is confirmed. Safe to call more
// than once for the same order (browser + webhook) – only the first call acts.
const fulfill = db.transaction((orderId, paymentId) => {
  const o = db.prepare("SELECT * FROM orders WHERE id=?").get(orderId);
  if (!o) throw new Error("Unknown order " + orderId);
  if (o.status === "paid") return subInfo(db.prepare("SELECT * FROM subscriptions WHERE id=?").get(o.sub_id), { renewed: !!o.renew_sub_id });
  const plan = planById(o.plan_id);
  const now = Date.now();
  let subId;
  const renewing = o.renew_sub_id && db.prepare("SELECT * FROM subscriptions WHERE id=?").get(o.renew_sub_id);
  if (renewing) {
    const from = Math.max(now, renewing.expires_at);
    db.prepare("UPDATE subscriptions SET plan_id=?, max_devices=?, expires_at=?, status='active' WHERE id=?")
      .run(plan.id, plan.devices, from + plan.days * DAY, renewing.id);
    subId = renewing.id;
  } else {
    subId = db.prepare(`INSERT INTO subscriptions (code, plan_id, max_devices, name, phone, email, source, created_at, expires_at)
                        VALUES (?,?,?,?,?,?, 'razorpay', ?, ?)`)
      .run(newUniqueCode(), plan.id, plan.devices, o.name, o.phone, o.email, now, now + plan.days * DAY).lastInsertRowid;
  }
  db.prepare("UPDATE orders SET status='paid', payment_id=?, sub_id=?, paid_at=? WHERE id=?").run(paymentId, subId, now, orderId);
  console.log(`✓ Paid: order ${orderId} payment ${paymentId} plan ${plan.id}${renewing ? " (renewal)" : ""}`);
  return subInfo(db.prepare("SELECT * FROM subscriptions WHERE id=?").get(subId), { renewed: !!renewing });
});

// Ask Razorpay directly whether an order has a captured payment of the right amount.
async function checkOrderWithRazorpay(order) {
  const list = await rzp("GET", `/v1/orders/${encodeURIComponent(order.id)}/payments`);
  const items = (list && list.items) || [];
  let paid = items.find(p => p.status === "captured" && p.amount === order.amount);
  if (!paid) {
    const auth = items.find(p => p.status === "authorized" && p.amount === order.amount);
    if (auth) {
      try { await rzp("POST", `/v1/payments/${auth.id}/capture`, { amount: order.amount, currency: "INR" }); } catch (e) { /* may already be captured */ }
      const again = await rzp("GET", `/v1/payments/${encodeURIComponent(auth.id)}`);
      if (again.status === "captured") paid = again;
    }
  }
  return paid ? fulfill(order.id, paid.id) : null;
}

// ---------------- Razorpay webhook (backup if the customer closes the page) ----------------
// Must be registered before express.json() because the signature is on the raw body.
app.post("/api/webhooks/razorpay", express.raw({ type: "*/*", limit: "1mb" }), (req, res) => {
  if (!WEBHOOK_SECRET) return res.status(503).json({ error: "webhook not configured" });
  const expected = crypto.createHmac("sha256", WEBHOOK_SECRET).update(req.body).digest("hex");
  if (!safeEqual(expected, req.get("x-razorpay-signature") || "")) return res.status(400).json({ error: "bad signature" });
  let ev;
  try { ev = JSON.parse(req.body.toString("utf8")); } catch { return res.status(400).json({ error: "bad json" }); }
  try {
    if (ev.event === "payment.captured" || ev.event === "order.paid") {
      const p = ev.payload && ev.payload.payment && ev.payload.payment.entity;
      const o = p && p.order_id && db.prepare("SELECT * FROM orders WHERE id=?").get(p.order_id);
      if (o && p.status === "captured" && p.amount === o.amount) fulfill(o.id, p.id);
    }
  } catch (e) { console.error("webhook error", e); }
  res.json({ ok: true });
});

app.use(express.json({ limit: "20kb" }));

// ---------------- public API ----------------
app.get("/api/config", (req, res) => {
  res.json({ plans: PLANS.map(publicPlan), trialDays: TRIAL_DAYS, keyId: KEY_ID, business: BUSINESS, paymentsReady: !!(KEY_ID && KEY_SECRET) });
});

// 1) Customer chose a plan → create a Razorpay order
app.post("/api/orders", limiter(20, 10 * 60e3), async (req, res, next) => {
  try {
    const { planId, name, phone, email, renewCode } = req.body || {};
    const plan = planById(planId);
    if (!plan) return fail(res, 400, "Please choose a plan.");
    const nm = String(name || "").trim().slice(0, 80);
    if (nm.length < 2) return fail(res, 400, "Please enter your name.");
    const ph = normPhone(phone);
    if (!/^[6-9]\d{9}$/.test(ph)) return fail(res, 400, "Please enter a valid 10‑digit mobile number.");
    const em = String(email || "").trim().slice(0, 120);
    if (em && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return fail(res, 400, "Please check your email address.");
    let renewId = null;
    if (renewCode && String(renewCode).trim()) {
      const s = db.prepare("SELECT * FROM subscriptions WHERE code=?").get(normCode(renewCode));
      if (!s) return fail(res, 400, "We couldn't find that login code. Check it, or leave it empty to get a new code.");
      renewId = s.id;
    }
    const amount = plan.price * 100;
    const order = await rzp("POST", "/v1/orders", {
      amount, currency: "INR", receipt: "pa_" + crypto.randomBytes(6).toString("hex"),
      notes: { plan: `${plan.name} (${plan.devices} devices)`, phone: ph, name: nm, renewal: renewId ? "yes" : "no" }
    });
    db.prepare(`INSERT INTO orders (id, plan_id, amount, name, phone, email, renew_sub_id, status, created_at)
                VALUES (?,?,?,?,?,?,?, 'created', ?)`).run(order.id, plan.id, amount, nm, ph, em || null, renewId, Date.now());
    res.json({ orderId: order.id, amount, currency: "INR", keyId: KEY_ID, plan: publicPlan(plan),
               prefill: { name: nm, contact: "+91" + ph, email: em || undefined } });
  } catch (e) { next(e); }
});

// 2) Razorpay checkout finished in the browser → verify it and give the code
app.post("/api/orders/verify", limiter(30, 10 * 60e3), async (req, res, next) => {
  try {
    const { razorpay_order_id: oid, razorpay_payment_id: pid, razorpay_signature: sig } = req.body || {};
    if (!oid || !pid || !sig) return fail(res, 400, "Missing payment details.");
    const order = db.prepare("SELECT * FROM orders WHERE id=?").get(String(oid));
    if (!order) return fail(res, 404, "We couldn't find this order.");
    const expected = crypto.createHmac("sha256", KEY_SECRET).update(`${oid}|${pid}`).digest("hex");
    if (!safeEqual(expected, sig)) return fail(res, 400, "This payment could not be verified. If money was taken, contact us with your payment ID.");
    if (order.status === "paid") return res.json(fulfill(order.id, order.payment_id));
    // Double-check with Razorpay that the money was actually received.
    let pay = await rzp("GET", `/v1/payments/${encodeURIComponent(pid)}`);
    if (pay.order_id !== order.id || pay.amount !== order.amount) return fail(res, 400, "Payment details don't match this order.");
    if (pay.status === "authorized") {
      try { await rzp("POST", `/v1/payments/${encodeURIComponent(pid)}/capture`, { amount: order.amount, currency: "INR" }); } catch (e) { /* auto-capture may have done it */ }
      pay = await rzp("GET", `/v1/payments/${encodeURIComponent(pid)}`);
    }
    if (pay.status !== "captured") return res.status(202).json({ pending: true, message: "Your payment is still being confirmed. This page will update in a moment." });
    res.json(fulfill(order.id, pid));
  } catch (e) { next(e); }
});

// 3) Check an order later (page refreshed, network dropped, webhook arrived)
app.get("/api/orders/:id", limiter(60, 10 * 60e3), async (req, res, next) => {
  try {
    const order = db.prepare("SELECT * FROM orders WHERE id=?").get(String(req.params.id));
    if (!order) return fail(res, 404, "Order not found.");
    if (order.status === "paid") return res.json({ status: "paid", ...fulfill(order.id, order.payment_id) });
    const done = await checkOrderWithRazorpay(order);
    res.json(done ? { status: "paid", ...done } : { status: "pending" });
  } catch (e) { next(e); }
});

// 4) "I paid but lost my code" – mobile number + Razorpay payment ID (pay_…)
app.post("/api/recover", limiter(10, 15 * 60e3), async (req, res, next) => {
  try {
    const ph = normPhone(req.body && req.body.phone);
    const pid = String((req.body && req.body.paymentId) || "").trim();
    if (!/^[6-9]\d{9}$/.test(ph) || !/^pay_[A-Za-z0-9]{6,30}$/.test(pid)) return fail(res, 400, "Enter your mobile number and the payment ID (it starts with pay_).");
    let order = db.prepare("SELECT * FROM orders WHERE payment_id=? AND phone=?").get(pid, ph);
    if (!order) {
      const pay = await rzp("GET", `/v1/payments/${encodeURIComponent(pid)}`).catch(() => null);
      order = pay && pay.order_id && db.prepare("SELECT * FROM orders WHERE id=? AND phone=?").get(pay.order_id, ph);
      if (order && order.status !== "paid") { const done = await checkOrderWithRazorpay(order); if (done) return res.json(done); }
    }
    if (!order || order.status !== "paid") return fail(res, 404, "We couldn't find a completed payment with these details. Please contact us and we'll help.");
    res.json(fulfill(order.id, order.payment_id));
  } catch (e) { next(e); }
});

// 5) Log in with a code on this device
app.post("/api/login", limiter(15, 15 * 60e3), (req, res) => {
  const code = normCode(req.body && req.body.code);
  const deviceId = String((req.body && req.body.deviceId) || "");
  const deviceName = String((req.body && req.body.deviceName) || "").trim().slice(0, 40);
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(deviceId)) return fail(res, 400, "Please refresh the page and try again.");
  const sub = db.prepare("SELECT * FROM subscriptions WHERE code=?").get(code);
  if (!sub || sub.status !== "active") return fail(res, 401, "This login code is not valid. Please check it and try again.");
  if (Date.now() > sub.expires_at) return fail(res, 403, `This subscription ended on ${fmtDate(sub.expires_at)}. Please renew to continue.`, { expired: true });
  const token = crypto.randomBytes(24).toString("base64url");
  const result = db.transaction(() => {
    const existing = db.prepare("SELECT * FROM devices WHERE sub_id=? AND device_id=?").get(sub.id, deviceId);
    if (existing) {
      db.prepare("UPDATE devices SET token_hash=?, last_seen=?, name=COALESCE(NULLIF(?,''), name) WHERE id=?").run(sha256(token), Date.now(), deviceName, existing.id);
      return true;
    }
    const used = db.prepare("SELECT COUNT(*) n FROM devices WHERE sub_id=?").get(sub.id).n;
    if (used >= sub.max_devices) return false;
    db.prepare("INSERT INTO devices (sub_id, device_id, name, token_hash, created_at, last_seen) VALUES (?,?,?,?,?,?)")
      .run(sub.id, deviceId, deviceName || `Device ${used + 1}`, sha256(token), Date.now(), Date.now());
    return true;
  })();
  if (!result) {
    const plan = planById(sub.plan_id);
    return fail(res, 409, `Maximum devices have already been logged in. The ${plan ? plan.name : ""} plan allows ${sub.max_devices} device${sub.max_devices > 1 ? "s" : ""}, and all are in use. Ask a family member to log out on one device (or remove it under Devices), or upgrade your plan.`, { limit: true });
  }
  res.json({ token, session: subInfo(sub) });
});

// Logged-in requests send "Authorization: Bearer <token>"
function auth(req, res, next) {
  const t = (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!t) return fail(res, 401, "Please log in again.");
  const dev = db.prepare("SELECT * FROM devices WHERE token_hash=?").get(sha256(t));
  if (!dev) return fail(res, 401, "This device was logged out. Please log in again.", { loggedOut: true });
  const sub = db.prepare("SELECT * FROM subscriptions WHERE id=?").get(dev.sub_id);
  if (!sub || sub.status !== "active") return fail(res, 401, "This subscription is no longer active.", { loggedOut: true });
  if (Date.now() > sub.expires_at) return fail(res, 403, `Your subscription ended on ${fmtDate(sub.expires_at)}. Please renew to continue.`, { expired: true, code: sub.code });
  db.prepare("UPDATE devices SET last_seen=? WHERE id=?").run(Date.now(), dev.id);
  req.dev = dev; req.sub = sub; next();
}
app.get("/api/session", auth, (req, res) => res.json(subInfo(req.sub)));
app.post("/api/logout", auth, (req, res) => { db.prepare("DELETE FROM devices WHERE id=?").run(req.dev.id); res.json({ ok: true }); });
app.get("/api/devices", auth, (req, res) => {
  const list = db.prepare("SELECT id, name, created_at, last_seen FROM devices WHERE sub_id=? ORDER BY created_at").all(req.sub.id);
  res.json({ ...subInfo(req.sub), devices: list.map(d => ({ id: d.id, name: d.name, since: d.created_at, lastSeen: d.last_seen, current: d.id === req.dev.id })) });
});
app.delete("/api/devices/:id", auth, (req, res) => {
  const r = db.prepare("DELETE FROM devices WHERE id=? AND sub_id=?").run(Number(req.params.id), req.sub.id);
  res.json({ ok: r.changes > 0 });
});

// ---------------- owner admin (/admin) ----------------
function adminAuth(req, res, next) {
  if (ADMIN_PASSWORD.length < 10) return res.status(503).send("Admin is locked. Set ADMIN_PASSWORD (at least 10 characters) in the .env file and restart.");
  const [type, b64] = (req.get("authorization") || "").split(" ");
  const pass = type === "Basic" && b64 ? Buffer.from(b64, "base64").toString().split(":").slice(1).join(":") : "";
  if (!safeEqual(sha256(pass), sha256(ADMIN_PASSWORD))) {
    res.set("WWW-Authenticate", 'Basic realm="Parivaar admin", charset="UTF-8"');
    return res.status(401).send("Admin login required.");
  }
  next();
}
const adminLimiter = limiter(60, 5 * 60e3);
app.get("/admin", adminLimiter, adminAuth, (req, res) => res.sendFile(path.join(__dirname, "admin", "admin.html")));
app.use("/api/admin", adminLimiter, adminAuth);
app.get("/api/admin/overview", (req, res) => {
  const subs = db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM devices d WHERE d.sub_id=s.id) devices_used
                           FROM subscriptions s ORDER BY s.created_at DESC LIMIT 500`).all();
  const orders = db.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200").all();
  const revenue = db.prepare("SELECT COALESCE(SUM(amount),0) total, COUNT(*) n FROM orders WHERE status='paid'").get();
  const now = Date.now();
  res.json({
    plans: PLANS.map(publicPlan),
    stats: { activeSubs: subs.filter(s => s.status === "active" && s.expires_at > now).length, paidOrders: revenue.n, revenue: revenue.total / 100 },
    subs: subs.map(s => ({ ...s, plan: (planById(s.plan_id) || {}).name, expired: s.expires_at < now })),
    orders
  });
});
app.get("/api/admin/subs/:id/devices", (req, res) => {
  res.json(db.prepare("SELECT id, name, created_at, last_seen FROM devices WHERE sub_id=? ORDER BY created_at").all(Number(req.params.id)));
});
// Give a code by hand (e.g. someone paid in cash)
app.post("/api/admin/codes", (req, res) => {
  const { planId, name, phone, days } = req.body || {};
  const plan = planById(planId);
  if (!plan) return fail(res, 400, "Choose a plan.");
  const d = Number(days) > 0 ? Math.min(Number(days), 3650) : plan.days;
  const now = Date.now(), code = newUniqueCode();
  db.prepare(`INSERT INTO subscriptions (code, plan_id, max_devices, name, phone, source, created_at, expires_at)
              VALUES (?,?,?,?,?, 'manual', ?, ?)`).run(code, plan.id, plan.devices, String(name || "").slice(0, 80), normPhone(phone), now, now + d * DAY);
  res.json({ code, plan: plan.name, devices: plan.devices, expiresOn: fmtDate(now + d * DAY) });
});
app.post("/api/admin/subs/:id/reset-devices", (req, res) => {
  const r = db.prepare("DELETE FROM devices WHERE sub_id=?").run(Number(req.params.id));
  res.json({ removed: r.changes });
});
app.post("/api/admin/subs/:id/extend", (req, res) => {
  const sub = db.prepare("SELECT * FROM subscriptions WHERE id=?").get(Number(req.params.id));
  if (!sub) return fail(res, 404, "Not found.");
  const days = Math.min(Math.max(Number(req.body && req.body.days) || 0, 1), 3650);
  const exp = Math.max(Date.now(), sub.expires_at) + days * DAY;
  db.prepare("UPDATE subscriptions SET expires_at=?, status='active' WHERE id=?").run(exp, sub.id);
  res.json({ expiresOn: fmtDate(exp) });
});
app.post("/api/admin/subs/:id/status", (req, res) => {
  const status = req.body && req.body.status === "cancelled" ? "cancelled" : "active";
  db.prepare("UPDATE subscriptions SET status=? WHERE id=?").run(status, Number(req.params.id));
  if (status === "cancelled") db.prepare("DELETE FROM devices WHERE sub_id=?").run(Number(req.params.id));
  res.json({ status });
});

// ---------------- website files ----------------
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"], maxAge: "1h" }));
app.use("/api", (req, res) => fail(res, 404, "Not found."));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, "public", "index.html")));

app.use((err, req, res, next) => {
  if (!err.expose) console.error(err);
  fail(res, err.status || 500, err.expose ? err.message : "Something went wrong. Please try again.");
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Parivaar AI running on http://localhost:${PORT}`));
}
module.exports = app;
