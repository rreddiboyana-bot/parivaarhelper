// ============================================================
//  PLANS – edit prices, devices and days here.
//  The website reads these from the server, so this is the
//  only place you need to change them.
//  price is in rupees. days = how long one payment lasts.
// ============================================================
module.exports = {
  TRIAL_DAYS: 7,
  PLANS: [
    { id: "S", name: "Solo",          price: 99,   period: "month", days: 30,  devices: 1, blurb: "For one person managing the home." },
    { id: "D", name: "Duo",           price: 149,  period: "month", days: 30,  devices: 2, blurb: "For a couple sharing the load." },
    { id: "F", name: "Family",        price: 249,  period: "month", days: 30,  devices: 4, blurb: "Parents and kids on their own phones.", popular: true },
    { id: "J", name: "Joint Family",  price: 399,  period: "month", days: 30,  devices: 6, blurb: "Grandparents, parents and kids." },
    { id: "Y", name: "Family Yearly", price: 2499, period: "year",  days: 365, devices: 4, blurb: "Family plan for a year. Save ₹489." }
  ]
};
